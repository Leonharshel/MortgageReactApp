import React from 'react';
import NavBar from './NavBar';
function sgp() {
 return (
 <div>
 <NavBar />
 <h2>Check Loan Status</h2>
 <p>Check the status of your loan application by entering your application ID below.</p>
 {/* Add loan application status checker here */}
 </div>
 );
};
export default sgp;
