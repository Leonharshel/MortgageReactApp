import React, { useEffect, useState } from 'react';
import './index.css';
import NavBar from './NavBar';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import Header from './Header';
import { Link } from 'react-router-dom';
import axios from 'axios';

const Status = () => {
  const [loanStatus, setLoanStatus] = useState('Not Applied');
  const [loanNumber, setLoanNumber] = useState('');

  useEffect(() => {
    // Fetch data from the database
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Make an API call to fetch the loan number from the database
      const response = await axios.get('https://your-api-endpoint.com/loan-number');
      const data = response.data;

      // Update the state with the fetched loan number
      setLoanNumber(data.loanNumber);

      // Update the loan status based on the loan number presence
      if (data.loanNumber) {
        setLoanStatus('Approved');
      } else {
        setLoanStatus('Not Applied');
      }
    } catch (error) {
      console.error('Error fetching loan data:', error);
    }
  };

  return (
    <div>
      <Header />
      <NavBar />

      <Container>
        <h1 className="title text-center">Loan Status</h1>
        <Row>
          <Col md={6}>
            <Card className="card mb-4">
              <Card.Body>
                <Card.Title className="card-title">Loan Details</Card.Title>
                <hr className="divider" />
                <p>
                  <strong>Status:</strong> <span className="text-success">{loanStatus}</span>
                </p>
                {loanNumber && (
                  <p>
                    <strong>Loan Number:</strong> {loanNumber}
                  </p>
                )}
              </Card.Body>
            </Card>
          </Col>
          <Col md={6}>
            {!loanNumber && (
              <Card className="card mb-4">
                <Card.Body>
                  <Card.Title className="card-title">Apply for Another  Loan</Card.Title>
                  <hr className="divider" />
                  <Link to="/loanpage/personaldetails">
                    <Button variant="primary">Apply For Another Loan</Button>
                  </Link>
                </Card.Body>
              </Card>
            )}
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Status;
